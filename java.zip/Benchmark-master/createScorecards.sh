mvn validate -Pbenchmarkscore -Dexec.args="expectedresults-1.2.csv results"
